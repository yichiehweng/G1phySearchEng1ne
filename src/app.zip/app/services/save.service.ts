import { Injectable } from '@angular/core';
import {SaveHistory} from '../model/saveModel';

@Injectable()
export class SaveService {
  SaveHistoryArray: SaveHistory[] = [];
  constructor() { }
  addNewRecord(record:string){
    this.SaveHistoryArray.push(new SaveHistory(record));
  }
  getSearchRecord():SaveHistory[]{
    return this.SaveHistoryArray;
  }

}
