import { Component, OnInit } from '@angular/core';
import{ SearchService} from '../../services/search.service';
import {SaveService} from '../../services/save.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  giphys: string[] = [];

  constructor(private searchService : SearchService, private saveService:SaveService) { }

  process(input: HTMLInputElement): void {
    this.searchService.PerformSearch(input.value)
    this.giphys =this.searchService.getSearchResults();
    console.log(this.giphys);
    this.saveService.addNewRecord(input.value);
  }

  ngOnInit() {
  }

}
