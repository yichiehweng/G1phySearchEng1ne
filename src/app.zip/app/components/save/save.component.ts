import { Component, OnInit } from '@angular/core';
import {SaveHistory} from '../../model/saveModel';
import {SaveService} from '../../services/save.service';

@Component({
  selector: 'app-save',
  templateUrl: './save.component.html',
  styleUrls: ['./save.component.css']
})
export class SaveComponent implements OnInit {
  saveRecords: SaveHistory[];
  constructor(private saveService:SaveService) { }

  ngOnInit() {
    this.saveRecords= this.saveService.getSearchRecord()
    console.log(this.saveService.getSearchRecord());
  }

}
